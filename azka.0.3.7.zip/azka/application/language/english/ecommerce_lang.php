<?php 

$lang['ecommerce'] = array(
	'list' => 'list',
	'product' => 'product',
);

?>