<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['cms-version'] = 'akzn-cms.0.3.6'; 
$config['theme'] = 'spe';
$config['maintenance_mode'] = false;
$config['maintenance_ips'] = array('');
$config['image_path'] = 'img/product/';

?>