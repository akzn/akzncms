<?php
/*menu*/
$lang['home'] = 'Home';
$lang['products'] = 'Our Product';
$lang['about'] = 'About Us';
$lang['contact'] = 'Contact Us';
$lang['services'] = 'Services';
$lang['projects'] = 'Projects';

/*shop*/
$lang['category'] = 'Category';
$lang['search'] = 'Search';
$lang['all'] = 'All';
$lang['show_all'] = 'Show All';
$lang['search'] = 'Search';

/*btn*/
$lang['btn_read_more'] = 'Read More';
$lang['btn_see_more'] = 'See More';
$lang['btn_more'] = 'More';
$lang['btn_send_message'] = 'Send Message';


/*Footer*/
$lang['get_in_touch'] = 'Get in Touch';
$lang['visit_us_at'] = 'Visit Us At';
$lang['office_hours'] = 'Office Hours';
$lang['monday'] = 'Monday';
$lang['saturday'] = 'Saturday';
$lang['sunday'] = 'Sunday';