<?php

$lang['slider_heading_1'] = 'Your trusted partner in heavy equipment peripherals';
$lang['slider_heading_2'] = 'Various Items';
$lang['slider_heading_3'] = 'High Quality';

// $lang['slider_content_1'] = 'Your trusted partner in heavy equipment peripherals';
$lang['slider_content_2'] = 'Providing various types of heavy equipment for construction, mining, and others.';
$lang['slider_content_3'] = 'The units we sell have gone through adequate feasibility test';


?>