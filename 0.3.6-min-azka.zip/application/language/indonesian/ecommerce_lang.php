<?php 

$lang['ecommerce'] = array(
	'list' => 'daftar',
	'product' => 'produk',
);

?>