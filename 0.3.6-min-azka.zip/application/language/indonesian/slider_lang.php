<?php

$lang['slider_heading_1'] = 'Mitra Terpercaya Untuk Kebutuhan Alat Berat Anda';
$lang['slider_heading_2'] = 'BERBAGAI PILIHAN';
$lang['slider_heading_3'] = 'Mutu Terjamin';

// $lang['slider_content_1'] = 'Bergerak dalam bidang jual beli alat berat (heavy equipments), kami selalu mengembangkan diri untuk menjadi mitra yang dapat dipercaya';
$lang['slider_content_2'] = 'Menyediakan berbagai jenis alat berat untuk berbagai macam keperluan konstruksi, pembangunan, penambangan, dan lain-lain.';
$lang['slider_content_3'] = 'Unit yang kami jual sudah melalui uji kelayakan yang memadai';


?>