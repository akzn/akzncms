<?php
/*menu*/
$lang['home'] = 'Beranda';
$lang['products'] = 'Produk';
$lang['about'] = 'Tentang';
$lang['contact'] = 'Kontak';
$lang['services'] = 'Service';
$lang['projects'] = 'Proyek';

/*shop*/
$lang['category'] = 'Kategori';
$lang['search'] = 'Cari';
$lang['all'] = 'Semua';
$lang['show_all'] = 'Lihat Semua';
$lang['search'] = 'Cari';

/*btn*/
$lang['btn_read_more'] = 'Lebih Lanjut';
$lang['btn_see_more'] = 'Lihat Lainnya';
$lang['btn_more'] = 'Lainnya';
$lang['btn_send_message'] = 'Kirim Pesan';

/*Footer*/
$lang['get_in_touch'] = 'Hubungi Kami';
$lang['visit_us_at'] = 'Alamat';
$lang['office_hours'] = 'Jam Kantor';
$lang['monday'] = 'Senin';
$lang['saturday'] = 'Sabtu';
$lang['sunday'] = 'Minggu';